import mysql.connector
from selenium.webdriver.firefox.options import Options
from selenium import webdriver 
import re


def product_fetch(search_query):
    options = Options()
  #  options.add_argument('--headless')
    browser = webdriver.Firefox(options=options)
    browser.get('https://www.amazon.in/s?k='+search_query+'&ref=nb_sb_noss')
    browser.implicitly_wait(5)
    names = browser.find_elements_by_css_selector(".a-color-base.a-text-normal")
    price = browser.find_elements_by_css_selector(".a-price-whole")
    link_lists = browser.find_elements_by_css_selector("a.a-link-normal.a-text-normal")
    names = [x.text for x in names[:15]]
    price = [x.text for x in price[:15]]
    link_lists = [x.get_attribute('href') for x in link_lists[:30]]
    link_list = []
    for i in  range(len(link_lists)):
        if(i%2!=0):
            link_list.append(link_lists[i])
            
    images = browser.find_elements_by_class_name('s-image')
    
    images = [x.get_attribute('src') for x in images[:15] ]
    browser.close()
    mydb = mysql.connector.connect(
            host="localhost",
            user="dettrax",
            passwd="toor",
            database="website"
            )
    mycursor = mydb.cursor()
    mycursor.execute("set foreign_key_checks=0")
    mycursor.execute("delete from website_product_temp")
    mycursor.execute("ALTER TABLE website_product_temp AUTO_INCREMENT = 0 ")
    mycursor.execute("set foreign_key_checks=0")
    mycursor.execute("ALTER TABLE website.website_product CONVERT TO CHARACTER SET utf8")
    mycursor.execute("ALTER TABLE website.website_product_temp CONVERT TO CHARACTER SET utf8")
    for i in range(len(images)):
        if (names[i]!='' and price[i]!='' and link_list[i]!= '' and images[i]!= ''):
            sql = "INSERT INTO website_product (product_name,product_price,product_url,image_urls) VALUES (%s,%s,%s,%s)"
            sql_temp = "INSERT INTO website_product_temp (product_name,product_price,product_url,image_urls) VALUES (%s,%s,%s,%s)"
            price_no = ''
            extract_number = re.findall(r'\d+',price[i])
            for j in extract_number:
                price_no+=j
            val = (" ".join(names[i].split(' ')[:5]),int(price_no),link_list[i],images[i])
            mycursor.execute(sql, val)
            mycursor.execute(sql_temp,val)
    mydb.commit()
    mydb.close()
    