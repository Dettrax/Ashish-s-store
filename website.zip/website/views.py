from django.shortcuts import render
from django.http import HttpResponse
import mysql.connector
from website.spyder import spyder
import pandas as pd
import datetime
from . import  Auto_email as mail
# Create your views here.
def index(request):
    return render(request,'website/index.html',{})

def clear_cart(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )
    mycursor = mydb.cursor()
    mycursor.execute('SET FOREIGN_KEY_CHECKS=0')
    mycursor.execute("delete from website_cart")
    mydb.commit()
    mydb.close()
    return render(request,'website/cart.html')

def search(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )
    
    mycursor = mydb.cursor()

    email = request.POST['username']
    passwd = request.POST['password']
    email_data = []
    pass_data = []
    mycursor.execute("select * from website_user")
    for x in mycursor:
        email_data.append(x[3])
        pass_data.append(x[5])
    mydb.close()
    if(email.lower() not in [x.lower() for x in email_data] or passwd not in pass_data):
        return render(request,'website/index_alert.html')
    else:
        return render(request,'website/search.html')

def list_product(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )
    
    mycursor = mydb.cursor()

    query = request.POST['search_query']
    spyder.product_fetch(query)
    display_list = []
    mycursor.execute("select * from website_product_temp")
    for x in mycursor:
        display_list.append(x)
    class_list = ['new','hot','sale','sale','hot','new','sale','new','sale']
    objects = []
    class Data:
        def __init__(self,classes,data):
            self.class_list = classes
            self.name = data[1]
            self.price = data[2]
            self.product_link = data[3]
            self.image_link = data[4]
    for i in range(9):
        temp = Data(class_list[i],display_list[i])
        objects.append(temp)
    mydb.close()
    return render(request,'website/categories.html',{'datas':objects,'Query':query.title()})

def cart(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )    
    mycursor = mydb.cursor()
    pro_price = request.GET['price']
    pro_name = request.GET['name']
    sql = "insert into website_cart (product_name,product_price) VALUES (%s,%s)"
    val = (pro_name,pro_price)
    mycursor.execute(sql,val)
    mydb.commit()
    mydb.close()    
    return HttpResponse("<script>window.history.back()</script>")

def cart_final(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )    
    mycursor = mydb.cursor()
    display_list = []
    mycursor.execute("select c.product_name,c.product_price, p.image_urls from website_cart c left join website_product p on p.product_name = c.product_name and p.product_price = c.product_price")
    for x in mycursor:
        display_list.append(x)
    display_list = pd.DataFrame(display_list)
    display_list = display_list.drop_duplicates(subset=1)
    objects = []
    class Data:
        def __init__(self,num,name,price,img):
            self.name = name
            self.price = price
            self.img = img
            self.num = num
    number = [i for i in range(len(display_list))]
    for i in number:
        temp = Data(i+1,display_list[0].iloc[i],display_list[1].iloc[i],display_list[2].iloc[i])
        objects.append(temp)
    mydb.close()
    try:
        return render(request,'website/cart.html',{'datas':objects,'total':sum(display_list[1])})
    except:
        return HttpResponse("<script>window.history.back()</script>")

def check_out(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )    
    mycursor = mydb.cursor(buffered=True)
    email = request.POST['emailadd_submit']
    display_list = []
    product_ids = []
    user_ids = []
    sql = "select id from website_user u where u.email = %s"
    value = (email,)
    mycursor.execute(sql,value)
    for x in mycursor:
        user_ids.append(x)
    mycursor.execute("select c.product_name,c.product_price, p.image_urls from website_cart c left join website_product p on p.product_name = c.product_name and p.product_price = c.product_price")
    for x in mycursor:
        display_list.append(x)
    display_list = pd.DataFrame(display_list)
    display_list = display_list.drop_duplicates(subset=1)
    for i in range(len(display_list)):
        sql1 = "select id from website_product p where p.image_urls=%s and p.product_price=%s"
        val1 = (display_list[2].iloc[i],int(display_list[1].iloc[i]))
        mycursor.execute(sql1,val1)
        for x in mycursor:
            product_ids.append(x) 
    for i in range(len(product_ids)):
        sql3 = "insert into website_orders(order_date,customer_details_id,product_details_id) values (%s,%s,%s)"
        date_now = datetime.datetime.today().strftime("%Y/%m/%d")
        val3 = (date_now,user_ids[0][0],product_ids[i][0])
        mycursor.execute(sql3,val3)
    mydb.commit()
    mydb.close()
    return render(request,'website/checkout.html',{'price':sum(display_list[1])})

def login(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )
    mycursor = mydb.cursor()
    user_name = request.POST['usernamesignup']
    email = request.POST['emailsignup']
    password = request.POST['passwordsignup']
    contact = request.POST['contact']
    try:
        sql = "INSERT INTO website_user (first_name,last_name,email,contact,password) VALUES (%s,%s,%s,%s,%s)"
        val = (user_name.split(' ')[0],user_name.split(' ')[1],email,int(contact),password)
        mycursor.execute(sql, val)
        mydb.commit()
        mydb.close()
        return render(request,'website/index.html')
    except:
        mydb.close()
        return HttpResponse("<script>alert('You made a mistake in registering name kindly put a space between first name and surname.')</script><a href='./'>Follow This link to register again!</a>")

def bye(request):
    address = request.POST['add']
    contact = request.POST['mob']
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )
    mycursor = mydb.cursor()
    display_list = []
    product_ids = []
    user_ids = []
    sql = "select id from website_user u where u.contact = {}".format(contact)
    mycursor.execute(sql)
    for x in mycursor:
        user_ids.append(x)
    mycursor.execute("select c.product_name,c.product_price, p.image_urls from website_cart c left join website_product p on p.product_name = c.product_name and p.product_price = c.product_price")
    for x in mycursor:
        display_list.append(x)
    display_list = pd.DataFrame(display_list)
    display_list = display_list.drop_duplicates(subset=1)
    mycursor.execute('SET FOREIGN_KEY_CHECKS=0')
    for i in range(len(display_list)):
        sql1 = "select id from website_product p where p.image_urls=%s and p.product_price=%s"
        val1 = (display_list[2].iloc[i],int(display_list[1].iloc[i]))
        mycursor.execute(sql1,val1)
        for x in mycursor:
            product_ids.append(x) 
    for i in range(len(product_ids)):
        sql ="insert into website_courier(address,customer_details_id,product_details_id) values(%s,%s,%s)"
        val4 = (address,user_ids[0][0],product_ids[i][0])
        mycursor.execute(sql,val4)
    if (request.POST['payment_radio'] == 'Debit'):
        card_no =  request.POST['card_no']
        cvv = request.POST['cvv']
        for i in range((len(product_ids))):
            sql = "insert into website_payment(method,order_details_id,product_details_id) values(%s,%s,%s)"
            val = ('Debit',user_ids[0][0],product_ids[i][0])
            mycursor.execute(sql,val)
            mydb.commit()
            sql2 = ("select id from website_payment p where p.order_details_id=%s and p.product_details_id=%s")
            val2 = (user_ids[0][0],product_ids[i][0])
            mycursor.execute(sql2,val2)
            for x in mycursor: pass
            sql3 = "insert into website_debit(card_no,cvv,payment_id_id) values(%s,%s,%s)"
            val3 = (card_no,cvv,x[0])
            mycursor.execute(sql3,val3)
    if (request.POST['payment_radio'] == 'Cash'):
        for i in range((len(product_ids))):
            sql = "insert into website_payment(method,order_details_id,product_details_id) values(%s,%s,%s)"
            val = ('Cash',user_ids[0][0],product_ids[i][0])
            mycursor.execute(sql,val)
            mydb.commit()
    mycursor.execute("delete from website_cart")
    mydb.commit()
    mycursor.execute("select id,first_name,last_name,email from website_user u where u.contact={}".format(contact))
    for x in mycursor: pass
    name = x[1]+" "+x[2]
    email_add = x[3]
    mycursor.execute("select product_details_id from website_orders o where o.customer_details_id={}".format(x[0]))
    product_boug = []
    product_det = []
    for x in mycursor: product_boug.append(x)
    for i in product_boug: 
        mycursor.execute("select product_name,product_price from website_product p where p.id={}".format(i[0]))
        for x in mycursor :
            product_det.append(x)
            print(x)
    product_name = []
    price = []
    for i in product_det:
        product_name.append(i[0])
        price.append(i[1])
    try:
        mail.send_mail(email_add,name,product_name,price)
    except:
        mydb.close()
        #Possible error, email address missing in the mail script.
        return HttpResponse("<script>alert('Email of the billing details cannot be sent,please contact admin for further details.')</script>")
    mycursor.execute("insert into website_orders_dat (customer_details_id,product_details_id,order_date) select customer_details_id,product_details_id,order_date from website_orders")
    mycursor.execute("delete from website_orders")
    mydb.commit()
    mydb.close()
    
    return render(request,'website/bye.html')
    
def feedback(request):
    mydb = mysql.connector.connect(
      host="localhost",
      user="dettrax",
      passwd="toor",
      database="website"
    )
    mycursor = mydb.cursor()
    mycursor.execute('SET FOREIGN_KEY_CHECKS=0')
    comment = request.POST['subject']
    sql = "insert into website_feedback(user_comment) values (%s)"
    val=(comment,)
    mycursor.execute(sql,val)
    mydb.commit()
    mydb.close()
    return render(request,'website/index.html')
    
    
    
    
    