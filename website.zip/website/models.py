from django.db import models
# Create your models here.
class user(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50,default="")
    contact = models.CharField(max_length=10)    

class product(models.Model):
    product_name = models.CharField(max_length = 300)
    product_price = models.BigIntegerField()
    product_url =  models.CharField(max_length = 1000)
    image_urls = models.CharField(max_length = 1000,default="")
    
class product_temp(models.Model):
    product_name = models.CharField(max_length = 300)
    product_price = models.BigIntegerField()
    product_url =  models.CharField(max_length = 1000)
    image_urls = models.CharField(max_length = 1000,default="")


class orders(models.Model):
    customer_details = models.ForeignKey(user,on_delete=models.CASCADE)
    product_details = models.ForeignKey(product,on_delete=models.CASCADE,default="")
    order_date = models.DateTimeField(auto_now_add=True , blank=True)
      
class payment(models.Model):
    method = models.CharField(max_length = 10)
    product_details = models.ForeignKey(product,on_delete=models.CASCADE,default="")
    order_details = models.ForeignKey(orders,on_delete=models.CASCADE,default="")
    
class debit(models.Model):
    payment_id = models.ForeignKey(payment,on_delete=models.CASCADE)
    card_no = models.IntegerField()
    cvv = models.IntegerField()

class courier(models.Model):
    address = models.CharField(max_length=1000)
    customer_details = models.ForeignKey(user,on_delete=models.CASCADE)
    product_details = models.ForeignKey(product,on_delete=models.CASCADE,default="")
        
class feedback(models.Model):
    user_comment = models.CharField(max_length = 1000)

class cart(models.Model):
    product_name = models.CharField(max_length = 300)
    product_price = models.BigIntegerField()

class orders_dat(models.Model):
    customer_details = models.ForeignKey(user,on_delete=models.CASCADE)
    product_details = models.ForeignKey(product,on_delete=models.CASCADE,default="")
    order_date = models.DateTimeField(auto_now_add=True , blank=True)
