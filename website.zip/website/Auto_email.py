import smtplib
from email.mime.text import MIMEText

def send_mail(email_add,username,name,price):
    SMTP_SERVER = "smtp.mail.yahoo.com"
    SMTP_PORT = 587
    SMTP_USERNAME = ""
    SMTP_PASSWORD = ""
    EMAIL_FROM = ""
    EMAIL_TO = email_add
    EMAIL_SUBJECT = "ORDER Conformation"
    co_msg = """
    Hello {},
    Your Product {} is confirmed to be delevered within a week.
    Your total bill amount is {}.
    Thank you for shopping with Ashish's Store.
    
    
    
    
    
    Your's truly,
    Ashish Pandey.
    """.format(username,name,sum(price))
    msg = MIMEText(co_msg)
    msg['Subject'] = EMAIL_SUBJECT
    msg['From'] = EMAIL_FROM 
    msg['To'] = EMAIL_TO
    debuglevel = True
    mail = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
    mail.set_debuglevel(debuglevel)
    mail.starttls()
    mail.login(SMTP_USERNAME, SMTP_PASSWORD)
    mail.sendmail(EMAIL_FROM, EMAIL_TO, msg.as_string())
    mail.quit()
