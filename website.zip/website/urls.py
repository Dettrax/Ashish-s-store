from django.urls import path
from . import views
urlpatterns = [
    path('', views.index , name="Homepage"),
    path('search',views.search , name="Search"),
    path('login', views.login , name="login"),
    path('list_product',views.list_product,name="products"),
    path('cart.html',views.cart_final,name="Cart"),
    path('categories.html',views.list_product,name="products"),
    path('checkout.html',views.check_out,name="checkout"),
    path('cart_store.html',views.cart,name='cart'),
    path('clear.html',views.clear_cart,name='clear'),
    path('confirm.html',views.bye,name='bye'),
    path('feedback',views.feedback,name='feedback')
]
